import numpy as np
from scipy import signal
import matplotlib.pyplot as plt
import csv

t = np.linspace(0, 1, 500)
saw_signal = signal.sawtooth(2 * np.pi * 5 * t) + 1
data = saw_signal*(4096/3.3)
new_data = [];
for i in data:
    new_data.append(int(i));
data = new_data;
with open('pila.csv', 'w', encoding='UTF8') as f:
    writer = csv.writer(f)
    writer.writerow(data)
f.close()
with open('pila.h', 'w') as f:
    f.write('#ifndef INC_SINE_WAVE_H_\n#define INC_SINE_WAVE_H_\n#include <stdint.h>\nextern uint16_t SINE_WAVE[500];\n#endif')
with open('pila.c', 'w') as f:
    f.write('#include "pila.h"\nuint16_t SINE_WAVE[500] = {\n#include "pila.csv"\n};')
plt.plot(t, saw_signal)
print(data)

plt.show()