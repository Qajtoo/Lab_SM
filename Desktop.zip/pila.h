#ifndef INC_SINE_WAVE_H_
#define INC_SINE_WAVE_H_
#include <stdint.h>
extern uint16_t SINE_WAVE[500];
#endif